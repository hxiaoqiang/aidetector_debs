/home/taiho/work/start.sh
/home/taiho/work/capture -i 32 -d 7 &