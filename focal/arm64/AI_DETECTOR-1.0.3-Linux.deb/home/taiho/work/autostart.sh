sudo ./start.sh
sudo ./capture -i 32 -d 7