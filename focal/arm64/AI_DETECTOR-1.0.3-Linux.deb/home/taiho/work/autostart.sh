
sudo /home/taiho/work/start.sh
sudo /home/taiho/work/capture -i 32 -d 7 -n 1  &
sudo /home/taiho/work/server &