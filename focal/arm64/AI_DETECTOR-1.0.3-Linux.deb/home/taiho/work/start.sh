sysctl -w kernel.sched_rt_runtime_us=-1
echo 990000 > /sys/fs/cgroup/cpu,cpuacct/cpu.rt_runtime_us
cd /sys/fs/cgroup/cpuset/
mkdir cpu5
sudo echo 5 > cpu5/cpuset.cpus
sudo echo 0 > cpu5/cpuset.mems
sudo echo 1 > cpuset.cpu_exclusive
sudo echo 0 > cpuset.sched_load_balance
sudo echo 1 > cpu5/cpuset.cpu_exclusive
sudo echo 1 > cpu5/cpuset.mem_exclusive

# mkdir cpu4
# sudo echo 4 > cpu4/cpuset.cpus
# sudo echo 0 > cpu4/cpuset.mems
# sudo echo 1 > cpu4/cpuset.cpu_exclusive
# sudo echo 0 > cpu4/cpuset.mem_exclusive
